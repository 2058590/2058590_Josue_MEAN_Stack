
//import * as fs from "fs";
import { Item } from "./Item";

let data : {name:string, id:number, price:number, img:string}[] = [
    {"name":"water bottle",
    "id":1000,
    "price":2.50,
    "img":""},
    
    {"name":"bacon dog snacks",
        "id":1001,
        "price":3.50,
        "img":""},
        
    {"name":"chocolate bar",
        "id":1002,
        "price":1.0,
        "img":""},
        
    {"name":"shirt",
        "id":1003,
        "price":4.50,
        "img":""},
        
    {"name":"chips",
        "id":1004,
        "price":2.25,
        "img":""}
]

function loadData() : Item[] {
    let inventory: Item[] = [];
    for(var i in data)
    {
        inventory.push(new Item(data[i].name, data[i].id, data[i].price, data[i].img));
    }

    return inventory;
}

function print(inventory:any) {
    let content = "<form>";
    for(var i in inventory){
        content += `<div>${inventory[i]}<label>Quantity  </label><input type="text" id="${i}"></div><br/>`;
        quants.push(0);
    }
    content += "</form>"
    return content;
}

function addValues()
{
    let total = 0;
    for(var i in quants){
        let el = document.getElementById(i);
        if(el != null){
        try{
            let htmlel = (<HTMLInputElement>el);
            let v = (htmlel).value;
            console.log(v);
            let k = JSON.parse(v);
            quants[i] = k;
            total += k; 
            
        }catch(e){
            console.log(e);
        }
        }else{
            console.log("it's null");
        }

    }

    let el = document.getElementById("items");
    if(el != null)
        el.innerHTML = JSON.stringify(total);

    sessionStorage.setItem("quants",JSON.stringify(quants));
    sessionStorage.setItem("total", JSON.stringify(total));
    

}

function updateCheckout(element:HTMLElement)
{
    let cost = 0.0;
    let total = 0;
    let item = sessionStorage.getItem("quants"); 
    if(item != null){
        quants = JSON.parse(item);
    }

    console.log("quantities:"+item);

    let content = "<table>";
    for(var i in quants){
        if(quants[i] > 0){
            content += `<tr><td>${inventory[i]['name']}</td>  <td>$${inventory[i]["price"]}</td><td>${quants[i]}</td></tr><br/>`;
            total += quants[i];
            cost += quants[i]*inventory[i]["price"];
        }
    }
    console.log(cost);
    console.log(quants);
    content += "</table><br/>"
    content += `<table id="total" class="highlight"><tr><td>Total:<div>$${cost}</div></td><td>#Items:<div>${total}</div></td></tr></table>`;

    element.innerHTML = content;

}


export let quants : number[] = [];
export let inventory = loadData();
export let content = print(inventory);
let element = document.getElementById("inventory");
if(element != null){
    element.innerHTML = content;
}

element = document.getElementById("add");
if(element != null){
    element.onclick = addValues;
}

element = document.getElementById("checkout");
if(element != null){
    updateCheckout(element);
}